﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TemplateWizard;
using System.Windows.Forms;
using EnvDTE;

namespace MyProjectWizard
{
    public class WizardImplementation : IWizard
    {
        private UserInputForm inputForm;
        private UserInputForm1 inputForm1;
        private UserInputForm2 inputForm2;
        private string customMessage;
        private bool bot;
        private bool tab;
        private bool messagingExtension;
        private bool isWizardActive = true;
        private string activeWizard = "1";
        // This method is called before opening any item that
        // has the OpenInEditor attribute.
        public void BeforeOpeningFile(ProjectItem projectItem)
        {
        }

        public void ProjectFinishedGenerating(Project project)
        {
        }

        // This method is only called for item templates,
        // not for project templates.
        public void ProjectItemFinishedGenerating(ProjectItem
            projectItem)
        {
        }

        // This method is called after the project is created.
        public void RunFinished()
        {
        }

        public void RunStarted(object automationObject,
            Dictionary<string, string> replacementsDictionary,
            WizardRunKind runKind, object[] customParams)
        {
            try
            {
                // Display a form to the user. The form collects
                // input for the custom message.
                inputForm = new UserInputForm();
                inputForm.ShowDialog();
                
                if (isWizardActive)
                {
                    myWizard:
                    if (activeWizard == "1")
                    {
                        customMessage = UserInputForm.CustomMessage;
                        messagingExtension = UserInputForm.MessagingExtension;
                        tab = UserInputForm.Tab;
                        bot = UserInputForm.Bot;

                        // Add custom parameters.
                        replacementsDictionary.Add("$custommessage$",
                            customMessage);
                        replacementsDictionary.Add("$messagingExtension$",
                                messagingExtension.ToString());
                        replacementsDictionary.Add("$tab$",
                                tab.ToString());
                        replacementsDictionary.Add("$bot$",
                                bot.ToString());
                        activeWizard ="2";
                        isWizardActive = false;
                        inputForm1 = new UserInputForm1();
                        inputForm1.ShowDialog();
                        goto myWizard;
                    }
                   else if (activeWizard == "2")
                    {
                        inputForm2 = new UserInputForm2();
                        inputForm2.ShowDialog();
                        activeWizard = "3";
                        isWizardActive = false;
                        goto myWizard;
                    }
                    else if (activeWizard == "3")
                    {
                        
                        // Here we should not call goto again as we no more wizards are showing just need to take all the inputs and do manifest creation

                    }
                }
                customMessage = UserInputForm.CustomMessage;
                messagingExtension = UserInputForm.MessagingExtension;
                tab = UserInputForm.Tab;
                bot = UserInputForm.Bot;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        // This method is only called for item templates,
        // not for project templates.
        public bool ShouldAddProjectItem(string filePath)
        {
            return true;
        }
    }

    public partial class UserInputForm : Form
    {
        private static string customMessage;
        private static string activeWizard;
        private static bool bot;
        private static bool tab;
        private static bool messagingExtension;
        private static bool isWizardActive;
        private TextBox textBox1;
        private Label label1;
        private Label label2;
        private Button button1;
        private Button button2;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private CheckBox checkBox3;


        public UserInputForm()
        {

            // this.components = new System.ComponentModel.Container();
            this.label1 = new Label();
            this.label2 = new Label();
            this.checkBox1 = new CheckBox();
            this.checkBox2 = new CheckBox();
            this.checkBox3 = new CheckBox();
            this.button1 = new Button();
            this.button2 = new Button();
            this.textBox1 = new TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(596, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "Create a new Teams Application";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(823, 36);
            this.label2.TabIndex = 1;
            this.label2.Text = "Select the way(s) in which your application will extend Teams";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(30, 191);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(2594, 76);
            this.checkBox1.TabIndex = 2;
            this.checkBox1.Text = "Messaging extension​ \nMessaging extensions can help users craft more effect messages by enabling them to query an external system, and insert the results in a rich, structured format complete with actionable buttons.";
            // resources.GetString("checkBox1.Text");
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.Location = new System.Drawing.Point(30, 278);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(1662, 76);
            this.checkBox2.TabIndex = 3;
            this.checkBox2.Text = "Tab \nTabs provide a full-screen embedded web experience configured for the person" +
    ", channel or group chat where it is installed.";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox3.Location = new System.Drawing.Point(31, 373);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(1346, 76);
            this.checkBox3.TabIndex = 4;
            this.checkBox3.Text = "Bot \nConversational bots interact with members of the conversation through chat a" +
    "nd respond to events.";
            this.checkBox3.UseVisualStyleBackColor = true;

            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1005, 502);
            this.button1.Name = "btnNext";
            this.button1.Size = new System.Drawing.Size(139, 52);
            this.button1.TabIndex = 5;
            this.button1.Text = "Next";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(787, 502);
            this.button2.Name = "btnBack";
            this.button2.Size = new System.Drawing.Size(139, 52);
            this.button2.TabIndex = 6;
            this.button2.Text = "Back";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1222, 638);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();
            // textBox1 = new TextBox();
            //textBox1.Location = new System.Drawing.Point(10, 25);
            //textBox1.Size = new System.Drawing.Size(70, 20);
            // this.Controls.Add(textBox1);
        }
        public static string CustomMessage
        {
            get
            {
                return customMessage;
            }
            set
            {
                customMessage = value;
            }
        }

        public static bool Tab
        {
            get
            {
                return tab;
            }
            set
            {
                tab = value;
            }
        }

        public static bool Bot
        {
            get
            {
                return bot;
            }
            set
            {
                bot = value;
            }
        }
        public static bool MessagingExtension
        {
            get
            {
                return messagingExtension;
            }
            set
            {
                messagingExtension = value;
            }
        }

        public static bool IsWizardActive
        {
            get
            {
                return isWizardActive;
            }
            set
            {
                isWizardActive = value;
            }
        }
        public static string ActiveWizard
        {
            get
            {
                return activeWizard;
            }
            set
            {
                activeWizard = value;
            }
        }
        private void btnNext_Click(object sender, EventArgs e)
        {
            // Have to Read the UserInputs Here
            customMessage = textBox1.Text;
            messagingExtension = checkBox1.Checked;
            tab = checkBox2.Checked;
            bot = checkBox3.Checked;
            // close the wizard and Navigate to the next wizard
            this.Close();
            activeWizard = "1";
            isWizardActive = true;
            // else close the wizard to create the project
            // this.Close();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            // Have to Read the UserInputs Here
            customMessage = textBox1.Text;
            messagingExtension = checkBox1.Checked;
            tab = checkBox2.Checked;
            bot = checkBox3.Checked;
            // close the wizard and Navigate to the next wizard

            // else close the wizard to create the project
            this.Close();
        }
    }

    public partial class UserInputForm1 : Form
    {
        private static string customMessage;
        private static string activeWizard;
        private static bool bot;
        private static bool tab;
        private static bool messagingExtension;
        private static bool isWizardActive;
        private TextBox textBox1;
        private Label label1;
        private Label label2;
        private Label label3;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private Button button1;
        private Button button2;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private CheckBox checkBox3;


        public UserInputForm1()
        {

            // this.components = new System.ComponentModel.Container();
            this.label1 = new Label();
            this.label2 = new Label();
            this.label3 = new Label();
            this.radioButton1 = new RadioButton();
            this.radioButton2 = new RadioButton();
            this.button1 = new Button();
            this.button2 = new Button();
            this.textBox1 = new TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(596, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "Create a new Teams Application";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(823, 36);
            this.label2.TabIndex = 1;
            this.label2.Text = "Configure your bot";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(24, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(823, 36);
            this.label3.TabIndex = 1;
            this.label3.Text = "What type of bot would you like to use ?";

            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(30, 191);
            this.radioButton1.Name = "checkBox1";
            this.radioButton1.Size = new System.Drawing.Size(2594, 76);
            this.radioButton1.TabIndex = 2;
            this.radioButton1.Text = "A new Bot Framework Bot";
            // resources.GetString("checkBox1.Text");
            this.radioButton1.UseVisualStyleBackColor = true;


            // 
            // radioButton1
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.Location = new System.Drawing.Point(30, 191);
            this.radioButton2.Name = "checkBox1";
            this.radioButton2.Size = new System.Drawing.Size(2594, 76);
            this.radioButton2.TabIndex = 2;
            this.radioButton2.Text = "An existing bot hosted outside this project";
            // resources.GetString("checkBox1.Text");
            this.radioButton1.UseVisualStyleBackColor = true;

            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1005, 502);
            this.button1.Name = "btnNext";
            this.button1.Size = new System.Drawing.Size(139, 52);
            this.button1.TabIndex = 5;
            this.button1.Text = "Next";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(787, 502);
            this.button2.Name = "btnBack";
            this.button2.Size = new System.Drawing.Size(139, 52);
            this.button2.TabIndex = 6;
            this.button2.Text = "Back";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1222, 638);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();
            // textBox1 = new TextBox();
            //textBox1.Location = new System.Drawing.Point(10, 25);
            //textBox1.Size = new System.Drawing.Size(70, 20);
            // this.Controls.Add(textBox1);
        }
        public static string CustomMessage
        {
            get
            {
                return customMessage;
            }
            set
            {
                customMessage = value;
            }
        }

        public static bool Tab
        {
            get
            {
                return tab;
            }
            set
            {
                tab = value;
            }
        }

        public static bool Bot
        {
            get
            {
                return bot;
            }
            set
            {
                bot = value;
            }
        }
        public static bool MessagingExtension
        {
            get
            {
                return messagingExtension;
            }
            set
            {
                messagingExtension = value;
            }
        }

        public static bool IsWizardActive
        {
            get
            {
                return isWizardActive;
            }
            set
            {
                isWizardActive = value;
            }
        }
        public static string ActiveWizard
        {
            get
            {
                return activeWizard;
            }
            set
            {
                activeWizard = value;
            }
        }
        private void btnNext_Click(object sender, EventArgs e)
        {
            // Have to Read the UserInputs Here
            customMessage = textBox1.Text;
            messagingExtension = checkBox1.Checked;
            tab = checkBox2.Checked;
            bot = checkBox3.Checked;
            // close the wizard and Navigate to the next wizard
            this.Close();
            activeWizard = "3";
            isWizardActive = true;
            // else close the wizard to create the project
            // this.Close();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            // Have to Read the UserInputs Here
            customMessage = textBox1.Text;
            messagingExtension = checkBox1.Checked;
            tab = checkBox2.Checked;
            bot = checkBox3.Checked;
            // close the wizard and Navigate to the next wizard
            activeWizard = "2";
            isWizardActive = true;
            // else close the wizard to create the project
            this.Close();
        }
    }

    public partial class UserInputForm2 : Form
    {
        private static string customMessage;
        private static string activeWizard;
        private static bool bot;
        private static bool tab;
        private static bool messagingExtension;
        private static bool isWizardActive;
        private TextBox textBox1;
        private Label label1;
        private Label label2;
        private Label label3;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private Button button1;
        private Button button2;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private CheckBox checkBox3;


        public UserInputForm2()
        {

            // this.components = new System.ComponentModel.Container();
            this.label1 = new Label();
            this.label2 = new Label();
            this.label3 = new Label();
            this.radioButton1 = new RadioButton();
            this.radioButton2 = new RadioButton();
            this.button1 = new Button();
            this.button2 = new Button();
            this.textBox1 = new TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(596, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "Create a new Teams Application";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(823, 36);
            this.label2.TabIndex = 1;
            this.label2.Text = "Configure your bot";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(24, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(823, 36);
            this.label3.TabIndex = 1;
            this.label3.Text = "Configure your messaging extension";

            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(30, 191);
            this.radioButton1.Name = "checkBox1";
            this.radioButton1.Size = new System.Drawing.Size(2594, 76);
            this.radioButton1.TabIndex = 2;
            this.radioButton1.Text = "A new Bot Framework Bot";
            // resources.GetString("checkBox1.Text");
            this.radioButton1.UseVisualStyleBackColor = true;


            // 
            // radioButton1
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.Location = new System.Drawing.Point(30, 191);
            this.radioButton2.Name = "checkBox1";
            this.radioButton2.Size = new System.Drawing.Size(2594, 76);
            this.radioButton2.TabIndex = 2;
            this.radioButton2.Text = "An existing bot hosted outside this project";
            // resources.GetString("checkBox1.Text");
            this.radioButton1.UseVisualStyleBackColor = true;

            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1005, 502);
            this.button1.Name = "btnNext";
            this.button1.Size = new System.Drawing.Size(139, 52);
            this.button1.TabIndex = 5;
            this.button1.Text = "Next";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(787, 502);
            this.button2.Name = "btnBack";
            this.button2.Size = new System.Drawing.Size(139, 52);
            this.button2.TabIndex = 6;
            this.button2.Text = "Back";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1222, 638);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();
            // textBox1 = new TextBox();
            //textBox1.Location = new System.Drawing.Point(10, 25);
            //textBox1.Size = new System.Drawing.Size(70, 20);
            // this.Controls.Add(textBox1);
        }
        public static string CustomMessage
        {
            get
            {
                return customMessage;
            }
            set
            {
                customMessage = value;
            }
        }

        public static bool Tab
        {
            get
            {
                return tab;
            }
            set
            {
                tab = value;
            }
        }

        public static bool Bot
        {
            get
            {
                return bot;
            }
            set
            {
                bot = value;
            }
        }
        public static bool MessagingExtension
        {
            get
            {
                return messagingExtension;
            }
            set
            {
                messagingExtension = value;
            }
        }

        public static bool IsWizardActive
        {
            get
            {
                return isWizardActive;
            }
            set
            {
                isWizardActive = value;
            }
        }
        public static string ActiveWizard
        {
            get
            {
                return activeWizard;
            }
            set
            {
                activeWizard = value;
            }
        }
        private void btnNext_Click(object sender, EventArgs e)
        {
            // Have to Read the UserInputs Here
            customMessage = textBox1.Text;
            messagingExtension = checkBox1.Checked;
            tab = checkBox2.Checked;
            bot = checkBox3.Checked;
            // close the wizard and Navigate to the next wizard
            this.Close();
            activeWizard = "3";
            isWizardActive = true;
            // else close the wizard to create the project
            // this.Close();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            // Have to Read the UserInputs Here
            customMessage = textBox1.Text;
            messagingExtension = checkBox1.Checked;
            tab = checkBox2.Checked;
            bot = checkBox3.Checked;
            // close the wizard and Navigate to the next wizard

            // else close the wizard to create the project
            this.Close();
        }
    }
}