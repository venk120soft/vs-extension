
For creating the Wizard for the New Project Follow below instructions:
https://docs.microsoft.com/en-us/visualstudio/extensibility/how-to-use-wizards-with-project-templates?view=vs-2019

After that If you find difficulty in creating the Forms Just Add new project of type WindowsFormsApplication(.Net FrameWork) to the solution then design your Form.
Use the same designer content in Wizard Implementation.

Adding Additional User Inputs:
